const DEFAULT_LOCATION = {
  name: "New Delhi",
  admin1: "Delhi",
  country: "India",
  latitude: 28.6139,
  longitude: 77.209
};
const WORLD_BOUNDS = [[-85.05112878, -180], [85.05112878, 180]];

const state = {
  location: DEFAULT_LOCATION,
  risk: null,
  map: null,
  mapReady: false,
  mapResizeObserver: null,
  selectedMarker: null,
  riskSourceReady: false,
  resourceMarkers: new Map(),
  places: [],
  requestId: 0,
  searchRequestId: 0,
  searchController: null,
  placesController: null,
  weatherCache: new Map(),
  lastWeather: null
};

const $ = (id) => document.getElementById(id);

const actions = {
  LOW: {
    residents: ["Use normal heat precautions.", "Drink water regularly.", "Check updates if you work outdoors."],
    authorities: ["Maintain routine monitoring.", "Keep heat messages ready.", "Review hospital and cooling plans."]
  },
  WATCH: {
    residents: ["Increase hydration.", "Reduce long outdoor exposure.", "Take shade breaks.", "Check elderly people, children and people with health risks."],
    authorities: ["Increase public heat messaging.", "Prepare cooling centers if risk rises.", "Notify outdoor-work supervisors.", "Check water access in exposed areas."]
  },
  HIGH: {
    residents: ["Avoid unnecessary outdoor exposure.", "Use cooler indoor spaces.", "Take frequent water and rest breaks.", "Check vulnerable people nearby."],
    authorities: ["Consider opening cooling centers.", "Adjust outdoor-work hours.", "Increase emergency-department readiness.", "Issue heat-health warnings.", "Start vulnerable-person checks."]
  },
  EXTREME: {
    residents: ["Stay indoors or in a cooler safe place if possible.", "Avoid outdoor work except for urgent needs.", "Seek help for confusion, fainting, chest pain or heatstroke signs.", "Check elderly people, children, outdoor workers and people with health risks."],
    authorities: ["Open cooling centers.", "Increase emergency-department readiness.", "Shift outdoor work hours.", "Enforce hydration and rest requirements.", "Prepare disaster-response teams and power-grid capacity.", "Increase neighborhood outreach."]
  }
};

function clamp(value, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value));
}

function round(value, digits = 0) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function locationLabel(location) {
  return [location.name, location.admin1, location.country].filter(Boolean).join(", ");
}

function riskLevel(score) {
  if (score >= 82) return "EXTREME";
  if (score >= 64) return "HIGH";
  if (score >= 42) return "WATCH";
  return "LOW";
}

function riskColor(level, alpha = 1) {
  const colors = {
    LOW: `rgba(105, 217, 138, ${alpha})`,
    WATCH: `rgba(255, 194, 71, ${alpha})`,
    HIGH: `rgba(255, 114, 27, ${alpha})`,
    EXTREME: `rgba(255, 59, 48, ${alpha})`
  };
  return colors[level] || colors.WATCH;
}

function heatIndexC(tempC, rh) {
  const tempF = tempC * 9 / 5 + 32;
  if (tempF < 80) return tempC;
  const hiF =
    -42.379 + 2.04901523 * tempF + 10.14333127 * rh
    - 0.22475541 * tempF * rh - 0.00683783 * tempF ** 2
    - 0.05481717 * rh ** 2 + 0.00122874 * tempF ** 2 * rh
    + 0.00085282 * tempF * rh ** 2 - 0.00000199 * tempF ** 2 * rh ** 2;
  return (hiF - 32) * 5 / 9;
}

function apparentTemperatureC(tempC, rh, windKmh) {
  const windMs = windKmh / 3.6;
  const vaporPressure = (rh / 100) * 6.105 * Math.exp((17.27 * tempC) / (237.7 + tempC));
  return tempC + 0.33 * vaporPressure - 0.7 * windMs - 4;
}

function petC(tempC, rh, windKmh, radiation) {
  return tempC + (rh - 45) * 0.055 + radiation * 0.011 - Math.min(windKmh, 28) * 0.13;
}

function vulnerability(location) {
  const text = `${location.name || ""} ${location.admin1 || ""}`.toLowerCase();
  const metro = ["delhi", "mumbai", "kolkata", "chennai", "hyderabad", "ahmedabad", "bengaluru", "pune", "jaipur", "lucknow", "surat"].some((name) => text.includes(name));
  const coastal = ["mumbai", "chennai", "kolkata", "visakhapatnam", "kochi", "goa", "puducherry"].some((name) => text.includes(name));
  const dry = ["rajasthan", "jaipur", "jodhpur", "bikaner", "ahmedabad", "kutch"].some((name) => text.includes(name));
  const score = clamp(46 + (metro ? 18 : 0) + (coastal ? 8 : 0) + (dry ? 12 : 0), 35, 88);
  const notes = [
    metro ? "Dense urban areas can hold more heat through the day and night." : "Outdoor workers may face long heat exposure.",
    coastal ? "High humidity can make it harder for the body to cool down." : "Elderly people, children and people with health risks need extra checks.",
    dry ? "Strong sunlight and dry heat can raise daytime heat load." : "Prototype vulnerability will improve when official local layers are connected."
  ];
  return { score, notes };
}

function calculateRisk(current, location) {
  const heatIndex = heatIndexC(current.temperature, current.humidity);
  const apparent = current.apparent ?? apparentTemperatureC(current.temperature, current.humidity, current.wind);
  const pet = petC(current.temperature, current.humidity, current.wind, current.radiation);
  const vuln = vulnerability(location);
  const factors = {
    Temperature: clamp(((current.temperature - 26) / 18) * 100),
    Humidity: clamp(((current.humidity - 35) / 55) * 100),
    Wind: clamp(100 - (current.wind / 28) * 100),
    Radiation: clamp((current.radiation / 850) * 100),
    Vulnerability: vuln.score
  };
  const score = clamp(
    factors.Temperature * 0.28 +
    factors.Humidity * 0.19 +
    factors.Wind * 0.12 +
    factors.Radiation * 0.21 +
    factors.Vulnerability * 0.2
  );
  const level = riskLevel(score);
  return {
    score: Math.round(score),
    level,
    heatIndex,
    apparent,
    pet,
    factors,
    vuln,
    mortality: Math.round(clamp(score * 0.76 + vuln.score * 0.16 + Math.max(0, pet - 35) * 1.8)),
    hospital: Math.round(clamp(score * 0.82 + factors.Humidity * 0.12 + Math.max(0, heatIndex - 36) * 1.3))
  };
}

async function searchLocations(query, signal) {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", query);
  url.searchParams.set("count", "8");
  url.searchParams.set("language", "en");
  url.searchParams.set("format", "json");
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error("Location search failed");
  const data = await response.json();
  return data.results || [];
}

async function fetchWeather(location) {
  const cacheKey = `${Number(location.latitude).toFixed(3)}:${Number(location.longitude).toFixed(3)}`;
  const cached = state.weatherCache.get(cacheKey);
  if (cached && Date.now() - cached.at < 5 * 60 * 1000) return cached.weather;
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", location.latitude);
  url.searchParams.set("longitude", location.longitude);
  url.searchParams.set("hourly", "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,wind_direction_10m,shortwave_radiation");
  url.searchParams.set("forecast_days", "5");
  url.searchParams.set("timezone", "auto");
  const response = await fetch(url);
  if (!response.ok) throw new Error("Weather fetch failed");
  const weather = await response.json();
  state.weatherCache.set(cacheKey, { at: Date.now(), weather });
  if (state.weatherCache.size > 50) state.weatherCache.delete(state.weatherCache.keys().next().value);
  return weather;
}

function currentWeather(weather) {
  const hourly = weather.hourly;
  const now = Date.now();
  let index = 0;
  let best = Infinity;
  hourly.time.forEach((time, i) => {
    const diff = Math.abs(new Date(time).getTime() - now);
    if (diff < best) {
      best = diff;
      index = i;
    }
  });
  return weatherAt(hourly, index);
}

function weatherAt(hourly, index) {
  return {
    temperature: hourly.temperature_2m[index],
    humidity: hourly.relative_humidity_2m[index],
    apparent: hourly.apparent_temperature[index],
    wind: hourly.wind_speed_10m[index],
    windDirection: hourly.wind_direction_10m[index],
    radiation: hourly.shortwave_radiation[index],
    time: hourly.time[index]
  };
}

function setText(id, value) {
  const node = $(id);
  if (node) node.textContent = value;
}

function setValue(id, value) {
  const node = $(id);
  if (node) node.value = value;
}

function renderCurrent(location, current, risk) {
  const label = locationLabel(location);
  state.risk = risk;
  setText("selectedLocation", label);
  setText("riskScore", risk.score);
  setText("riskLevel", risk.level);
  setText("riskSummary", `${risk.level} thermal stress. Heat, humidity, wind, radiation and vulnerability combine into this score.`);
  setText("temperature", `${round(current.temperature, 1)}°C`);
  setText("humidity", `${round(current.humidity)}%`);
  setText("wind", `${round(current.wind, 1)} km/h`);
  setText("radiation", `${round(current.radiation)} W/m²`);
  setText("heatIndex", `${round(risk.heatIndex, 1)}°C`);
  setText("apparentTemp", `${round(risk.apparent, 1)}°C`);
  setText("pet", `${round(risk.pet, 1)}°C`);
  setText("mortalityRisk", `${risk.mortality}/100`);
  setText("hospitalRisk", `${risk.hospital}/100`);
  setText("whyTitle", `${risk.score}/100 is ${risk.level}`);
  setText("whyText", whyText(risk));
  setValue("formLocation", label);
  setValue("formRiskLevel", risk.level);
  setValue("formRiskScore", risk.score);
  setValue("formRiskInfo", whyText(risk));
  const latField = $("formLat");
  const lonField = $("formLon");
  if (latField) latField.value = location.latitude;
  if (lonField) lonField.value = location.longitude;
  renderFactors(risk.factors);
  renderVulnerability(risk);
  renderActions(risk.level);
}

function whyText(risk) {
  const strong = Object.entries(risk.factors)
    .filter(([, value]) => value >= 60)
    .map(([key]) => key.toLowerCase());
  if (!strong.length) return "Current conditions are moderate, but exposure can still affect vulnerable people.";
  return `${strong.join(", ")} are pushing the local thermal stress score upward.`;
}

function renderFactors(factors) {
  const list = $("factorList");
  list.innerHTML = "";
  Object.entries(factors).forEach(([name, value]) => {
    const row = document.createElement("div");
    row.className = "factor";
    row.innerHTML = `<span>${name}</span><span class="bar"><i style="--value:${Math.round(value)}%"></i></span><span>${Math.round(value)}%</span>`;
    list.appendChild(row);
  });
}

function renderVulnerability(risk) {
  setText("vulnerabilityTitle", risk.vuln.score >= 70 ? "Higher vulnerability" : risk.vuln.score >= 52 ? "Moderate vulnerability" : "Lower vulnerability");
  const list = $("vulnerabilityList");
  list.innerHTML = "";
  risk.vuln.notes.forEach((note) => list.appendChild(li(note)));
}

function renderActions(level) {
  const chosen = actions[level] || actions.WATCH;
  const residents = $("residentActions");
  const authorities = $("authorityActions");
  residents.innerHTML = "";
  authorities.innerHTML = "";
  chosen.residents.forEach((item) => residents.appendChild(li(item)));
  chosen.authorities.forEach((item) => authorities.appendChild(li(item)));
}

function li(text) {
  const item = document.createElement("li");
  item.textContent = text;
  return item;
}

function renderTimeline(weather, location) {
  const timeline = $("timeline");
  timeline.innerHTML = "";
  const grouped = {};
  weather.hourly.time.forEach((time, i) => {
    const day = time.slice(0, 10);
    grouped[day] ||= [];
    grouped[day].push(weatherAt(weather.hourly, i));
  });

  Object.entries(grouped).slice(0, 5).forEach(([date, values]) => {
    const peak = values
      .map((item) => calculateRisk(item, location))
      .sort((a, b) => b.score - a.score)[0];
    const day = new Intl.DateTimeFormat("en", { weekday: "short", day: "numeric" }).format(new Date(`${date}T12:00:00`));
    const card = document.createElement("article");
    card.className = "day";
    card.innerHTML = `
      <strong>${day}</strong>
      <b style="color:${riskColor(peak.level)}">${peak.level}</b>
      <span>${peak.score}/100 peak risk</span>
      <div class="day-meter"><i style="--value:${peak.score}%"></i></div>
    `;
    timeline.appendChild(card);
  });
}

function scheduleMapResize() {
  if (!state.map) return;
  cancelAnimationFrame(state.mapResizeFrame || 0);
  state.mapResizeFrame = requestAnimationFrame(() => {
    state.mapResizeFrame = requestAnimationFrame(() => {
      state.mapResizeFrame = 0;
      try { state.map.resize(); } catch (_) {}
    });
  });
}

function markerElement(kind, glyph, color) {
  const element = document.createElement("button");
  element.type = "button";
  element.className = `map-resource-marker ${kind}`;
  element.style.setProperty("--marker-color", color);
  element.textContent = glyph;
  return element;
}

function riskRadius(score) {
  return 1200 + (Number(score) || 0) * 45;
}

function updateMapOverlay(location, risk) {
  setText("mapOverlayLocation", `SELECTED LOCATION · ${locationLabel(location)}`);
  setText("mapRiskLevel", risk ? `${risk.level} · ${risk.score}/100` : "LOADING");
  const swatch = $("mapRiskSwatch");
  if (swatch) {
    swatch.style.background = risk ? riskColor(risk.level, 1) : "#261b12";
    swatch.style.boxShadow = risk ? `0 0 0 4px ${riskColor(risk.level, 0.18)}` : "none";
  }
}

function createMapInfoContent(place) {
  const wrap = document.createElement("div");
  const title = document.createElement("strong");
  title.textContent = place.name;
  const meta = document.createElement("div");
  meta.textContent = `${place.category === "hospital" ? "Hospital / clinic" : "Park / green space"} · ${distanceLabel(place.distanceKm)}`;
  wrap.append(title, meta);
  if (place.address) {
    const address = document.createElement("div");
    address.textContent = place.address;
    wrap.appendChild(address);
  }
  const link = document.createElement("a");
  link.href = place.osmUrl || `https://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lon}#map=17/${place.lat}/${place.lon}`;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  link.textContent = "Open map details";
  wrap.appendChild(link);
  return wrap;
}

function openMapInfo(place, marker) {
  if (!marker) return;
  const popup = new maplibregl.Popup({ offset: 18, closeButton: true, maxWidth: "320px" })
    .setDOMContent(createMapInfoContent(place));
  popup.setLngLat([place.lon, place.lat]).addTo(state.map);
}

function setSelectedMarker(location, risk = null) {
  if (!state.mapReady) return;
  state.selectedMarker?.remove();
  const element = markerElement("selected", "●", risk ? riskColor(risk.level, 1) : "#261b12");
  element.title = `${locationLabel(location)} — ${risk ? `${risk.level} heat risk` : "loading heat risk"}`;
  const marker = new maplibregl.Marker({ element, anchor: "center" })
    .setLngLat([location.longitude, location.latitude])
    .addTo(state.map);
  element.addEventListener("click", () => {
    const popup = new maplibregl.Popup({ offset: 18, closeButton: true })
      .setHTML(`<strong>${escapeHtml(locationLabel(location))}</strong><div>${risk ? `${risk.level} modeled heat risk · ${risk.score}/100` : "Heat risk loading"}</div>`);
    popup.setLngLat([location.longitude, location.latitude]).addTo(state.map);
  });
  state.selectedMarker = marker;
}

function clearResourceMarkers() {
  state.resourceMarkers.forEach(({ marker }) => marker.remove());
  state.resourceMarkers = new Map();
}

function addResourceMarker(place) {
  if (!state.mapReady) return null;
  const color = place.category === "hospital" ? "#26749a" : "#47785a";
  const element = markerElement(place.category === "hospital" ? "hospital" : "park", place.category === "hospital" ? "H" : "P", color);
  element.title = place.name;
  element.setAttribute("aria-label", `${place.category === "hospital" ? "Hospital" : "Park"}: ${place.name}`);
  const marker = new maplibregl.Marker({ element, anchor: "center" }).setLngLat([place.lon, place.lat]).addTo(state.map);
  element.addEventListener("click", () => {
    document.querySelectorAll(".resource-item.is-active").forEach((node) => node.classList.remove("is-active"));
    [...document.querySelectorAll(".resource-item")].find((node) => node.dataset.resourceId === place.id)?.classList.add("is-active");
    openMapInfo(place, marker);
  });
  state.resourceMarkers.set(place.id, { marker, info: place });
  return marker;
}

function syncMapResourceMarkers(places = state.places) {
  if (!state.mapReady) return;
  clearResourceMarkers();
  (places || []).forEach(addResourceMarker);
}

function installRiskLayer() {
  if (!state.mapReady || state.riskSourceReady) return;
  state.map.addSource("thrive-risk", {
    type: "geojson",
    data: { type: "Feature", geometry: { type: "Point", coordinates: [state.location.longitude, state.location.latitude] }, properties: { risk: 0 } }
  });
  state.map.addLayer({
    id: "thrive-risk-circle",
    type: "circle",
    source: "thrive-risk",
    paint: {
      "circle-radius": 50,
      "circle-color": "#d99a41",
      "circle-opacity": 0.16,
      "circle-stroke-color": "#d99a41",
      "circle-stroke-opacity": 0.8,
      "circle-stroke-width": 2
    }
  });
  state.riskSourceReady = true;
}

function updateRiskLayer(location, risk) {
  if (!state.mapReady || !state.riskSourceReady) return;
  const source = state.map.getSource("thrive-risk");
  if (!source) return;
  const score = Number(risk?.score || 0);
  const color = riskColor(risk?.level || "WATCH", 1);
  source.setData({
    type: "Feature",
    geometry: { type: "Point", coordinates: [location.longitude, location.latitude] },
    properties: { radius: riskRadius(score) / 100, color }
  });
  state.map.setPaintProperty("thrive-risk-circle", "circle-color", color);
  state.map.setPaintProperty("thrive-risk-circle", "circle-stroke-color", color);
  state.map.setPaintProperty("thrive-risk-circle", "circle-opacity", 0.17);
  state.map.setPaintProperty("thrive-risk-circle", "circle-stroke-opacity", 0.85);
  const px = Math.max(22, Math.min(110, 18 + score * 0.55));
  state.map.setPaintProperty("thrive-risk-circle", "circle-radius", px);
}

async function initMap() {
  if (state.map) return;
  const element = $("map");
  if (!element) return;
  try {
    const start = performance.now();
    while ((element.clientWidth <= 0 || element.clientHeight <= 0) && performance.now() - start < 4000) {
      await new Promise((resolve) => requestAnimationFrame(resolve));
    }
    if (element.clientWidth <= 0 || element.clientHeight <= 0) {
      setText("mapStatus", "Map container is not visible yet. Scroll to the map and it will initialize safely.");
      return;
    }
    if (!window.maplibregl) throw new Error("MapLibre failed to load");
    state.map = new maplibregl.Map({
      container: element,
      style: "https://tiles.openfreemap.org/styles/liberty",
      center: [state.location.longitude, state.location.latitude],
      zoom: 12,
      minZoom: 2,
      maxZoom: 18,
      attributionControl: true,
      renderWorldCopies: false,
      cooperativeGestures: false
    });
    state.map.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), "top-right");
    state.map.on("load", () => {
      state.mapReady = true;
      installRiskLayer();
      setSelectedMarker(state.location, state.risk);
      updateMapOverlay(state.location, state.risk);
      setText("mapStatus", "Map ready. Nearby hospitals and parks load automatically for the selected location.");
      scheduleMapResize();
      if (state.risk) updateRiskLayer(state.location, state.risk);
      syncMapResourceMarkers(state.places);
    });
    state.map.on("error", (event) => {
      console.warn("[map] MapLibre error", event?.error || event);
      setText("mapStatus", "Map tiles are having trouble loading. The location and risk panel still work.");
    });
    state.map.on("idle", scheduleMapResize);
    const resizeTarget = element.parentElement;
    if ("ResizeObserver" in window && resizeTarget) {
      state.mapResizeObserver = new ResizeObserver(() => scheduleMapResize());
      state.mapResizeObserver.observe(resizeTarget);
    }
    window.addEventListener("resize", scheduleMapResize, { passive: true });
    window.addEventListener("orientationchange", scheduleMapResize, { passive: true });
    document.addEventListener("visibilitychange", () => { if (!document.hidden) scheduleMapResize(); });
    setText("mapStatus", "Loading free map…");
  } catch (error) {
    console.error("[map] Map initialization failed:", error);
    setText("mapStatus", "Map could not initialize. Refresh once; if it persists, check WebGL and network access.");
  }
}

function updateMap(location, risk) {
  updateMapOverlay(location, risk);
  if (!state.map) return;
  const apply = () => {
    if (!state.mapReady) return;
    state.map.flyTo({ center: [location.longitude, location.latitude], zoom: 12, essential: true });
    setSelectedMarker(location, risk);
    updateRiskLayer(location, risk);
    syncMapResourceMarkers(state.places);
    setText("mapStatus", `${locationLabel(location)} · ${risk.level} modeled heat risk · nearby hospitals and parks are shown on the same map.`);
    scheduleMapResize();
  };
  if (state.mapReady) apply();
}

async function searchNearbyResources(location, requestId) {
  const response = await fetch(`/api/resources?lat=${encodeURIComponent(location.latitude)}&lon=${encodeURIComponent(location.longitude)}&radiusKm=10`, {
    headers: { Accept: "application/json" },
    signal: state.placesController?.signal
  });
  if (!response.ok) throw new Error("Nearby resource lookup failed");
  const data = await response.json();
  if (requestId !== state.requestId) return [];
  return Array.isArray(data.places) ? data.places : [];
}

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function distanceLabel(km) {
  return km < 1 ? "< 1 km" : `${km.toFixed(1)} km`;
}

function focusResource(place, item) {
  if (state.map && state.mapReady) {
    state.map.panTo({ lat: place.lat, lng: place.lon });
    state.map.setZoom(Math.max(state.map.getZoom(), 15));
    const entry = state.resourceMarkers?.get(place.id);
    if (entry) openMapInfo(place, entry.marker);
  }
  document.querySelectorAll(".resource-item.is-active").forEach((node) => node.classList.remove("is-active"));
  item?.classList.add("is-active");
}

function renderPlaces(places, requestId) {
  state.places = places;
  if (requestId !== state.requestId) return;
  clearResourceMarkers();
  const byCategory = { hospital: $("hospitalList"), park: $("parkList") };
  Object.values(byCategory).forEach((node) => { node.replaceChildren(); });
  places.forEach((place) => {
    if (requestId !== state.requestId) return;
    const directionUrl = place.osmUrl || `https://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lon}#map=17/${place.lat}/${place.lon}`;
    const card = document.createElement("article");
    card.className = "resource-item";
    card.dataset.resourceId = place.id;
    const title = document.createElement("strong"); title.textContent = place.name; card.appendChild(title);
    const type = document.createElement("span"); type.textContent = `${place.subtype} · ${distanceLabel(place.distanceKm)}`; card.appendChild(type);
    [place.address, place.openingHours].filter(Boolean).forEach((value) => {
      const meta = document.createElement("small"); meta.textContent = value; card.appendChild(meta);
    });
    const source = document.createElement("small"); source.textContent = "Source: community-mapped resource data"; source.textContent = "Source: OpenStreetMap / OpenFreeMap resource data"; card.appendChild(source);
    const focus = document.createElement("button"); focus.type = "button"; focus.textContent = "View on map";
    focus.addEventListener("click", () => focusResource(place, card)); card.appendChild(focus);
    const links = document.createElement("div"); links.className = "hospital-links";
    const directions = document.createElement("a"); directions.href = directionUrl; directions.target = "_blank"; directions.rel = "noopener noreferrer"; directions.textContent = "Directions"; links.appendChild(directions);
    if (place.phone) {
      const call = document.createElement("a"); call.href = `tel:${String(place.phone).replace(/[^+\d]/g, "")}`; call.textContent = "Call"; links.appendChild(call);
    }
    if (place.website) {
      try {
        const websiteUrl = new URL(place.website);
        if (["http:", "https:"].includes(websiteUrl.protocol)) {
          const website = document.createElement("a"); website.href = websiteUrl.href; website.target = "_blank";
          website.rel = "noopener noreferrer"; website.textContent = "Website"; links.appendChild(website);
        }
      } catch (_) {}
    }
    card.appendChild(links);
    byCategory[place.category].appendChild(card);
  });
  syncMapResourceMarkers(places);
}

async function fetchPlaces(location, requestId) {
  state.placesController?.abort();
  const controller = new AbortController(); state.placesController = controller;
  $("hospitalList").replaceChildren(); $("parkList").replaceChildren();
  setText("intelligenceLocation", locationLabel(location));
  setText("aiLocationHint", `Using ${locationLabel(location)} as the default location. Nearby hospitals and parks load automatically from the selected location.`);
  setText("hospitalStatus", "Finding nearby hospitals and parks automatically…");
  setText("aiStatus", "Waiting for nearby resource results and current heat risk…");
  setText("aiHeatSummary", ""); setText("aiHospitalSummary", ""); setText("aiParkSummary", ""); setText("aiDisclaimer", "");
  $("aiActions").replaceChildren(); $("aiChatLog")?.replaceChildren();
  try {
    const places = await searchNearbyResources(location, requestId);
    if (controller.signal.aborted || requestId !== state.requestId) return null;
    renderPlaces(places, requestId);
    setText("hospitalStatus", places.length ? `The map found ${places.filter((p) => p.category === "hospital").length} hospitals/clinics and ${places.filter((p) => p.category === "park").length} parks near ${location.name}.` : "The map found no nearby hospitals or parks within 10 km.");
    return places;
  } catch (error) {
    if (controller.signal.aborted || requestId !== state.requestId) return null;
    console.error("[places] Nearby resource lookup failed:", error);
    setText("hospitalStatus", "Nearby hospitals and parks could not be loaded right now. Try the location again.");
    setText("aiStatus", "The automatic location analysis is waiting for nearby resource data.");
    return [];
  }
}

async function analyzeLocation(location, risk, current, places, requestId) {
  if (requestId !== state.requestId) return;
  setText("aiStatus", "AI is analyzing this location…");
  try {
    const response = await fetch("/api/location-ai", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      signal: state.placesController?.signal,
      body: JSON.stringify({ location, risk: { score: risk.score, level: risk.level }, weather: { temperatureC: current.temperature, humidityPercent: current.humidity }, places })
    });
    if (!response.ok) throw new Error("AI analysis unavailable");
    const analysis = await response.json();
    if (requestId !== state.requestId) return;
    setText("aiStatus", analysis.locationSummary || "Not available");
    setText("aiHeatSummary", analysis.heatHealthSummary || "Not available");
    setText("aiDisclaimer", analysis.disclaimer || "");
    setText("aiHospitalSummary", analysis.hospitalSummary || "Not available");
    setText("aiParkSummary", analysis.parkSummary || "Not available");
    [...(analysis.hospitals || []), ...(analysis.parks || [])].forEach((note) => {
      const card = [...document.querySelectorAll(".resource-item")].find((node) => node.dataset.resourceId === note.id);
      if (!card || !note.reason || note.reason === "Not available") return;
      const reason = document.createElement("small"); reason.textContent = note.reason; card.appendChild(reason);
    });
    (analysis.recommendedActions || []).forEach((action) => $("aiActions").appendChild(li(action)));
    appendAIMessage(analysis.chatMessage || `Automatic scan complete for ${locationLabel(location)}. I used this location automatically and loaded nearby hospitals and parks.`);
  } catch (error) {
    if (error.name === "AbortError" || requestId !== state.requestId) return;
    setText("aiStatus", "AI location analysis is temporarily unavailable. Raw mapped results are still available below.");
  }
}

async function loadLocation(location) {
  const requestId = ++state.requestId;
  const latitude = Number(location.latitude), longitude = Number(location.longitude);
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90 || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    setText("riskSummary", "This location does not have valid coordinates. Choose another search result.");
    setText("mapStatus", "Invalid location coordinates.");
    return;
  }
  state.placesController?.abort();
  if (state.map && state.mapReady) {
    state.map.setCenter({ lat: latitude, lng: longitude });
    state.map.setZoom(12);
    setSelectedMarker(location);
    updateMapOverlay(location, null);
  }
  clearResourceMarkers();
  state.places = [];
  $("hospitalList").replaceChildren(); $("parkList").replaceChildren();
  setText("aiStatus", "Waiting for current weather and nearby resources…");
  setText("aiHeatSummary", ""); setText("aiHospitalSummary", ""); setText("aiParkSummary", "");
  setText("aiDisclaimer", "");
  $("aiActions").replaceChildren();
  state.risk = null;
  location.latitude = latitude; location.longitude = longitude;
  state.location = location;
  $("locationInput").value = location.name || "";
  setValue("formLocation", locationLabel(location));
  setValue("formRiskLevel", ""); setValue("formRiskScore", ""); setValue("formRiskInfo", "");
  $("formLat").value = latitude; $("formLon").value = longitude;
  setText("selectedLocation", locationLabel(location));
  setText("riskLevel", "Loading");
  setText("riskScore", "--");
  setText("riskSummary", "Loading live Open-Meteo data for the selected location.");
  setText("mapStatus", `Loading ${locationLabel(location)}...`);
  setText("hospitalStatus", "Waiting for weather and nearby resource lookup...");
  const placesPromise = fetchPlaces(location, requestId);

  try {
    const weather = await fetchWeather(location);
    if (requestId !== state.requestId) return;
    const current = currentWeather(weather);
    if (![current.temperature, current.humidity, current.wind, current.radiation].every(Number.isFinite)) throw new Error("Incomplete weather data");
    const risk = calculateRisk(current, location);
    renderCurrent(location, current, risk);
    renderTimeline(weather, location);
    updateMap(location, risk);
    const places = await placesPromise;
    if (requestId !== state.requestId) return;
    if (places) await analyzeLocation(location, risk, current, places, requestId);
  } catch (error) {
    if (requestId !== state.requestId) return;
    setText("riskLevel", "Unavailable");
    setText("riskSummary", "Live weather could not be loaded for this location. Try again or choose another location.");
    setText("mapStatus", "Weather data unavailable.");
    setText("aiStatus", "AI location analysis is temporarily unavailable until weather data loads.");
  }
}

function setupSearch() {
  const form = $("searchForm");
  const results = $("searchResults");
  let activeQuery = "";
  $("locationInput").addEventListener("input", (event) => {
    if (event.target.value.trim() === activeQuery) return;
    state.searchRequestId++;
    state.searchController?.abort();
    results.hidden = true;
  });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = $("locationInput").value.trim();
    if (!query) return;
    activeQuery = query;
    state.searchController?.abort();
    const controller = new AbortController(); state.searchController = controller;
    const searchRequestId = ++state.searchRequestId;
    results.hidden = false;
    results.innerHTML = "<button type=\"button\" disabled>Searching...</button>";
    try {
      const places = await searchLocations(query, controller.signal);
      if (searchRequestId !== state.searchRequestId) return;
      if (!places.length) {
        results.innerHTML = "<button type=\"button\" disabled>No location found. Try another name.</button>";
        return;
      }
      results.innerHTML = "";
      places.forEach((place) => {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = locationLabel(place);
        button.addEventListener("click", () => {
          state.searchRequestId++;
          state.searchController?.abort();
          results.hidden = true;
          loadLocation(place);
        });
        results.appendChild(button);
      });
    } catch (error) {
      if (error.name === "AbortError" || searchRequestId !== state.searchRequestId) return;
      results.innerHTML = "<button type=\"button\" disabled>Search unavailable right now.</button>";
    }
  });
}

function appendAIMessage(text, type = "assistant") {
  const log = $("aiChatLog");
  if (!log) return;
  const node = document.createElement("div");
  node.className = `ai-message ${type === "user" ? "user" : ""}`.trim();
  node.textContent = text;
  log.appendChild(node);
  log.scrollTop = log.scrollHeight;
}

async function askHospitalAI(question) {
  if (!question || !state.location || !state.risk) return;
  const button = $("aiChatForm")?.querySelector("button");
  button && (button.disabled = true);
  appendAIMessage(question, "user");
  appendAIMessage("AI is checking the selected location, heat risk and nearby mapped hospitals…");
  try {
    const current = state.lastWeather;
    const response = await fetch("/api/location-ai", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        mode: "question",
        question,
        location: state.location,
        risk: { score: state.risk.score, level: state.risk.level },
        weather: current ? { temperatureC: current.temperature, humidityPercent: current.humidity } : {},
        places: state.places
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "AI unavailable");
    const log = $("aiChatLog");
    const pending = log?.lastElementChild;
    if (pending && pending.textContent.startsWith("AI is checking")) pending.remove();
    appendAIMessage(data.answer || "Not available");
  } catch (error) {
    const log = $("aiChatLog");
    const pending = log?.lastElementChild;
    if (pending && pending.textContent.startsWith("AI is checking")) pending.remove();
    appendAIMessage("The AI service is temporarily unavailable. The automatic location summary above is still available.");
  } finally {
    button && (button.disabled = false);
  }
}

function setupHospitalAI() {
  const form = $("aiChatForm");
  if (!form) return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const input = $("aiQuestion");
    const question = input.value.trim();
    if (!question) return;
    input.value = "";
    askHospitalAI(question);
  });
}

function setupRegisterForm() {
  const form = $("registerForm");
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const status = $("formStatus");

    if (!$("consentBox").checked) {
      status.textContent = "Please agree to the Privacy Policy consent above to register.";
      return;
    }

    const currentLocation = state.location;
    const currentRisk = state.risk;

    const payload = {
      name: form.elements.name.value.trim(),
      phone: form.elements.phone.value.trim(),
      email: form.elements.email.value.trim(),
      consent: true,
      channels: {
        sms: $("channelSms").checked,
        whatsapp: $("channelWhatsapp").checked,
        call: $("channelCall").checked
      },
      location: {
        label: locationLabel(currentLocation),
        name: currentLocation?.name || "",
        admin1: currentLocation?.admin1 || "",
        country: currentLocation?.country || "",
        latitude: currentLocation?.latitude ?? null,
        longitude: currentLocation?.longitude ?? null
      },
      risk: currentRisk
        ? { level: currentRisk.level, score: currentRisk.score, summary: whyText(currentRisk) }
        : null
    };

    if (!payload.name || !payload.phone || !payload.email) {
      status.textContent = "Please fill in your name, phone number and email.";
      return;
    }

    const submitButton = form.querySelector("button[type=submit]");
    submitButton.disabled = true;
    status.textContent = "Sending registration...";

    try {
      const response = await fetch(form.action, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload)
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || result.ok === false) throw new Error(result.error || "Registration failed");

      const channelSummary = ["SMS", payload.channels.whatsapp ? "WhatsApp" : null, payload.channels.call ? "voice call (EXTREME only)" : null]
        .filter(Boolean)
        .join(", ");

      status.innerHTML = `<strong>INFORMATION REGISTERED</strong><br>You're registered for ${currentRisk ? currentRisk.level + " " : ""}heat and disaster alerts for ${locationLabel(currentLocation)} via ${channelSummary}. Your information has also been sent to the managing-officer workflow.`;
      form.reset();
      $("channelSms").checked = true;
    } catch (error) {
      status.textContent = "Registration could not be sent right now. If this keeps happening, the alert backend may not be configured yet — please try again later.";
    } finally {
      submitButton.disabled = false;
    }
  });
}

async function boot() {
  setupSearch();
  setupRegisterForm();
  setupHospitalAI();
  state.location = DEFAULT_LOCATION;
  if (document.fonts?.ready) await document.fonts.ready.catch(() => {});
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  await initMap();
  loadLocation(DEFAULT_LOCATION);
}

window.addEventListener("DOMContentLoaded", boot, { once: true });
