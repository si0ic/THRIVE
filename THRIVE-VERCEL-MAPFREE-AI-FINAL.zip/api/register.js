import twilio from "twilio";

function send(res, status, body) { return res.status(status).json(body); }

function clean(value, max = 500) {
  return typeof value === "string" ? value.replace(/[<>]/g, "").trim().slice(0, max) : "";
}

export default async function handler(req, res) {
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    return res.status(204).end();
  }
  if (req.method !== "POST") return send(res, 405, { ok: false, error: "Method not allowed." });
  const payload = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});

  const name = clean(payload?.name, 120);
  const email = clean(payload?.email, 254).toLowerCase();
  const phone = clean(payload?.phone, 40).replace(/[()\s-]/g, "");
  const location = payload?.location || {};
  const risk = payload?.risk || null;
  const consent = payload?.consent === true;
  const channels = payload?.channels || {};

  if (!name || !email || !phone) return send(res, 400, { ok: false, error: "Name, phone and email are required." });
  if (!consent) return send(res, 400, { ok: false, error: "Consent to the Privacy Policy is required." });
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) return send(res, 400, { ok: false, error: "Use an international phone number, for example +91XXXXXXXXXX." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { ok: false, error: "Email address looks invalid." });

  const latitude = Number(location.latitude);
  const longitude = Number(location.longitude);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    return send(res, 400, { ok: false, error: "Choose a valid location before registering." });
  }

  const record = {
    name,
    email,
    phone,
    channels: {
      sms: channels.sms !== false,
      whatsapp: channels.whatsapp === true,
      call: channels.call === true
    },
    location: {
      label: clean(location.label || `${location.name || ""}, ${location.admin1 || ""}, ${location.country || ""}`, 240),
      latitude,
      longitude
    },
    risk: risk && ["LOW", "WATCH", "HIGH", "EXTREME"].includes(risk.level)
      ? { level: risk.level, score: Number(risk.score) }
      : null,
    createdAt: new Date().toISOString()
  };

  const webhook = String(process.env.REGISTRATION_WEBHOOK_URL || "").trim();
  if (webhook) {
    try {
      await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(record)
      });
    } catch (error) {
      console.error("[register] registration webhook failed:", error.message);
    }
  }

  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const smsFrom = process.env.TWILIO_SMS_FROM;
  const waFrom = process.env.TWILIO_WHATSAPP_FROM;
  const voiceFrom = process.env.TWILIO_VOICE_FROM;
  const notifications = { sms: "not_configured", whatsapp: "not_configured", call: "not_configured" };

  if (sid && token) {
    try {
      const client = twilio(sid, token);
      const levelText = record.risk ? ` Current modeled risk is ${record.risk.level} (${record.risk.score}/100).` : "";
      const body = `THRIVE: You're registered for heat-health alerts for ${record.location.label}.${levelText} Reply STOP to opt out.`;

      if (record.channels.sms && smsFrom) {
        try {
          await client.messages.create({ from: smsFrom, to: phone, body });
          notifications.sms = "sent";
        } catch (error) {
          console.error("[register] SMS failed:", error.code || error.message);
          notifications.sms = "failed";
        }
      }

      if (record.channels.whatsapp && waFrom) {
        try {
          await client.messages.create({
            from: waFrom,
            to: `whatsapp:${phone}`,
            body
          });
          notifications.whatsapp = "sent";
        } catch (error) {
          console.error("[register] WhatsApp failed:", error.code || error.message);
          notifications.whatsapp = "failed";
        }
      }

      if (record.channels.call && voiceFrom && record.risk?.level === "EXTREME") {
        try {
          const voice = new twilio.twiml.VoiceResponse();
          voice.say(
            { language: process.env.TWILIO_VOICE_LANGUAGE || "en-IN" },
            `This is a THRIVE extreme heat alert for ${record.location.label}. The current modeled risk is extreme. Please move to a cooler place, avoid unnecessary outdoor exposure, and seek urgent medical help for severe heat illness.`
          );
          await client.calls.create({ from: voiceFrom, to: phone, twiml: voice.toString() });
          notifications.call = "initiated";
        } catch (error) {
          console.error("[register] voice call failed:", error.code || error.message);
          notifications.call = "failed";
        }
      }
    } catch (error) {
      console.error("[register] Twilio unavailable:", error.message);
    }
  }

  return send(res, 200, {
    ok: true,
    notifications,
    persistence: webhook ? "webhook" : "none"
  });
}
