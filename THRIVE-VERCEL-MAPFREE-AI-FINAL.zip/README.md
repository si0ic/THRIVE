# THRIVE — Vercel + OpenFreeMap + MapLibre + GPT-5.6

THRIVE is a heat-health risk prototype with one MapLibre map using the free OpenFreeMap public style, automatic nearby hospital/park lookup through OpenStreetMap/Overpass, and a location-aware AI assistant. OpenFreeMap requires no registration or API key.

## Vercel
1. Import this repository into Vercel.
2. Build command: `npm run build`.
3. Output directory: `dist`.
4. No map key or map ID is required.

Optional AI variable:
- `OPENAI_API_KEY` — enables the OpenAI Responses API.
- `OPENAI_MODEL` — defaults to `gpt-5.6-luna`.

The AI still works without an OpenAI key using a deterministic location/risk/resource analysis, so the hospital box does not silently fail.

## Automatic behavior
Selecting a city updates the same single map, heat-risk overlay, selected-location marker, nearby hospitals and nearby parks. The user does not need to instruct the AI to search.

## Main endpoints
- `/api/resources` — nearby hospitals and parks from OpenStreetMap/Overpass.
- `/api/location-ai` — automatic location analysis + follow-up chat; falls back locally if OpenAI is unavailable.
- `/api/register` — alert registration workflow.

## Map
MapLibre GL JS renders `https://tiles.openfreemap.org/styles/liberty`. OpenFreeMap states that its public instance is free, needs no registration/API key, and uses OpenStreetMap data.
